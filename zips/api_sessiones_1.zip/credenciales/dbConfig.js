module.exports = {
    localhost: '127.0.0.1',
    mysqlConfig: {
        user: 'usercoppel',
        password: 'gJaw6N2Cy53OJ88EZls63k40NKYidzv6',
        database: 'escolar',
        port: 9876
    },
    sshTunnelConfig: {
        username: 'literaturas',
        password: 'AJlajskjso3%',
        host: 'agcollege.edu.mx',
        port: 22
    },
    mysqlConfigDesarrollo: {
        user: 'root',
        password: 'UEJdjck5786Ji.',
        database: 'escolar',
        port: 9876
    },
    sshTunnelConfigDesarrollo: {
        username: 'agcolleges',
        password: 'AG*-daBhf*98G389+2heTrd*q*KJ+DL.JK+JGA*-Dl-k8asd*gp7',
        host: '164.90.144.135',
        port: 22
    }
}